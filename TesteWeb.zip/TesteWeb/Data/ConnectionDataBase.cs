using System;
using System.Data.SqlClient;

namespace WebApplication.Data
{
    public class ConnectionDataBase
    {
        protected SqlConnection Connection { get; }

        public ConnectionDataBase()
        {
            Connection = new SqlConnection(Startup.ConfigurationConnectionDataBase);
            Connection.Open();
        }

        protected void CloseConnection()
        {
            try
            {
                if (Connection != null)
                {
                    Connection.Close();
                    Connection.Dispose();
                }
            } catch (Exception exc) 
            {
                //logger error
            }
        }
    }
}