using System;

namespace WebApplication.Data
{
    internal class SelectResult : ISelectResult
    {
        private readonly object value;

        public SelectResult(object value)
        {
            this.value = value;
        }

        public override string ToString() => value.ToString();
        public byte ToByte() => Convert.ToByte(value);
        public short ToShort() => Convert.ToInt16(value);
        public int ToInt() => Convert.ToInt32(value);
        public long ToLong() => Convert.ToInt64(value);
        public float ToFloat() => Convert.ToSingle(value);
        public double ToDouble() => Convert.ToDouble(value);
        public decimal ToDecimal(byte decimals = 2) => Math.Round(Convert.ToDecimal(value), decimals);
        public DateTime ToDateTime() => Convert.ToDateTime(value);
        public TimeSpan ToTimeSpan() => ToDateTime().TimeOfDay;
        public char ToChar() => Convert.ToChar(value);
        public bool IsTrue() => ToChar() == 'S';
        public byte[] ToBytes() => (byte[])value;
    }
}