namespace WebApplication.Data
{
    public static class DataBaseProvider
    {
        public static ISelect NewSelect(string commandText) => new Select(commandText);
    }
}