using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace WebApplication.Data
{
    internal class Select : ConnectionDataBase, ISelect
    {
        private readonly List<Dictionary<string, object>> resultSet;
        private readonly Dictionary<string, object> paramaters;
        private int indexResult = -1;
        private readonly string commandText;

        public Select(string commandText)
        {
            resultSet = new List<Dictionary<string, object>>();
            paramaters = new Dictionary<string, object>();
            this.commandText = commandText;
        }

        public void AddParameter(string name, object value) => paramaters.Add(name, value);

        public void Execute()
        {
            SqlCommand command = null;
            try
            {
                command = new SqlCommand(commandText, Connection);
                foreach (var par in paramaters.Keys)
                {
                    command.Parameters.AddWithValue(par, paramaters[par]);
                }

                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var row = new Dictionary<string, object>();
                    for (var index = 0; index < reader.FieldCount; index++)
                    {
                        var name = reader.GetName(index);
                        var nameColumn = string.IsNullOrWhiteSpace(name) ? $"COLUNA_{index}" : name.Trim().ToUpper();
                        row.Add(nameColumn, reader.GetValue(index));
                    }
                    resultSet.Add(row);
                }

                reader.Dispose();

                if (resultSet.Any())
                {
                    indexResult = 0;
                }
            }
            catch
            {
                // log error...
                throw;
            }
            finally
            {
                CloseConnection();
            }
        }

        private void VereficaSeConsultaFoiAberta()
        {
            if (indexResult == -1)
            {
                // log error. Consulta não foi executada/aberta
                throw new Exception("A consulta não foi executada ou não retornou resultados."
                                    + Environment.NewLine
                                    + "Utilize o método 'Execute' para executar a consulta e 'Any' para verificar se existem resultados.");
            }
        }

        private string ExistsColumn(string nameColumn)
        {
            VereficaSeConsultaFoiAberta();

            if (nameColumn == null)
            {
                // log error. Nome de coluna não foi definido
                throw new Exception("O nome da coluna não foi especificado.");
            }

            if (!resultSet[indexResult].ContainsKey(nameColumn.ToUpper()))
            {
                // log error. Coluna não presente na seleção
                throw new Exception($"A coluna: '{nameColumn}' não estava presente na lista de seleção.");
            }

            return nameColumn.ToUpper();
        }

        public object Get(string nameColumn)
        {
            if (IsNull(nameColumn))
            {
                // log error. Coluna em estado nulo.
                throw new Exception($"A coluna: '{nameColumn}' estava em estado nulo.");
            }

            return resultSet[indexResult][nameColumn.ToUpper()];
        }

        public bool IsNull(string nameColumn)
        {
            var name = ExistsColumn(nameColumn);
            return resultSet[indexResult][name] == DBNull.Value;
        }

        public string GetString(string nameColumn) => Get(nameColumn).ToString();
        public string GetString(string nameColumn, string defaultValue) => IsNull(nameColumn) ? defaultValue : GetString(nameColumn);
        public string GetStringOrNull(string nameColumn) => IsNull(nameColumn) ? null : GetString(nameColumn);
        public byte GetByte(string nameColumn) => Convert.ToByte(Get(nameColumn));
        public byte GetByte(string nameColumn, byte defaultValue) => IsNull(nameColumn) ? defaultValue : GetByte(nameColumn);
        public byte? GetByteOrNull(string nameColumn) => IsNull(nameColumn) ? null : (byte?)GetByte(nameColumn);
        public short GetShort(string nameColumn) => Convert.ToInt16(Get(nameColumn));
        public short GetShort(string nameColumn, short defaultValue) => IsNull(nameColumn) ? defaultValue : GetShort(nameColumn);
        public short? GetShortOrNull(string nameColumn) => IsNull(nameColumn) ? null : (short?)GetShort(nameColumn);
        public int GetInt(string nameColumn) => Convert.ToInt32(Get(nameColumn));
        public int GetInt(string nameColumn, int defaultValue) => IsNull(nameColumn) ? defaultValue : GetInt(nameColumn);
        public int? GetIntOrNull(string nameColumn) => IsNull(nameColumn) ? null : (int?)GetInt(nameColumn);
        public long GetLong(string nameColumn) => Convert.ToInt64(Get(nameColumn));
        public long GetLong(string nameColumn, long defaultValue) => IsNull(nameColumn) ? defaultValue : GetLong(nameColumn);
        public long? GetLongOrNull(string nameColumn) => IsNull(nameColumn) ? null : (long?)GetLong(nameColumn);
        public float GetFloat(string nameColumn) => Convert.ToSingle(Get(nameColumn));
        public float GetFloat(string nameColumn, float defaultValue) => IsNull(nameColumn) ? defaultValue : GetFloat(nameColumn);
        public float? GetFloatOrNull(string nameColumn) => IsNull(nameColumn) ? null : (float?)GetFloat(nameColumn);
        public double GetDouble(string nameColumn) => Convert.ToDouble(Get(nameColumn));
        public double GetDouble(string nameColumn, double defaultValue) => IsNull(nameColumn) ? defaultValue : GetDouble(nameColumn);
        public double? GetDoubleOrNull(string nameColumn) => IsNull(nameColumn) ? null : (double?)GetDouble(nameColumn);
        public decimal GetDecimal(string nameColumn, byte decimals = 2) => Math.Round(Convert.ToDecimal(Get(nameColumn)), decimals);
        public decimal GetDecimal(string nameColumn, decimal defaultValue, byte decimals = 2) => IsNull(nameColumn) ? defaultValue : GetDecimal(nameColumn, decimals);
        public decimal? GetDecimalOrNull(string nameColumn, byte decimals = 2) => IsNull(nameColumn) ? null : (decimal?)GetDecimal(nameColumn, decimals);
        public DateTime GetDateTime(string nameColumn) => Convert.ToDateTime(Get(nameColumn));
        public DateTime GetDateTime(string nameColumn, DateTime defaultValue) => IsNull(nameColumn) ? defaultValue : GetDateTime(nameColumn);
        public DateTime? GetDateTimeOrNull(string nameColumn) => IsNull(nameColumn) ? null : (DateTime?)GetDateTime(nameColumn);
        public TimeSpan GetTimeSpan(string nameColumn) => GetDateTime(nameColumn).TimeOfDay;
        public TimeSpan GetTimeSpan(string nameColumn, TimeSpan defaultValue) => IsNull(nameColumn) ? defaultValue : GetTimeSpan(nameColumn);
        public TimeSpan? GetTimeSpanOrNull(string nameColumn) => IsNull(nameColumn) ? null : (TimeSpan?)GetTimeSpan(nameColumn);
        public char GetChar(string nameColumn) => Convert.ToChar(Get(nameColumn));
        public char GetChar(string nameColumn, char defaultValue) => IsNull(nameColumn) ? defaultValue : GetChar(nameColumn);
        public char? GetCharOrNull(string nameColumn) => IsNull(nameColumn) ? null : (char?)GetChar(nameColumn);
        public bool GetBoolean(string nameColumn) => IsNull(nameColumn) ? false : GetChar(nameColumn) == 'S';
        public byte[] GetBytes(string nameColumn) => (byte[])Get(nameColumn);
        public List<Dictionary<string, object>> GetAll() => resultSet;

        public void Loop(LoopSelect loopSelect)
        {
            if (indexResult > -1)
            {
                try
                {
                    for (var index = 0; index < resultSet.Count; index++)
                    {
                        indexResult = index;
                        loopSelect();
                    }
                }
                finally
                {
                    indexResult = 0;
                }
            }
        }

        public ISelectResult GetResult(Dictionary<string, object> rowData, string nameColumn)
        {
            VereficaSeConsultaFoiAberta();
            var name = ExistsColumn(nameColumn);
            var value = rowData[name];
            return value == DBNull.Value ? null : new SelectResult(value);
        }

        public bool Any() => indexResult > -1;
        public int Count() => resultSet.Count;
    }
}