using System;

namespace WebApplication.Data
{
    public interface ISelectResult
    {
        string ToString();
        byte ToByte();
        short ToShort();
        int ToInt();
        long ToLong();
        float ToFloat();
        double ToDouble();
        decimal ToDecimal(byte decimals = 2);
        DateTime ToDateTime();
        TimeSpan ToTimeSpan();
        char ToChar();
        bool IsTrue();
        byte[] ToBytes();
    }
}