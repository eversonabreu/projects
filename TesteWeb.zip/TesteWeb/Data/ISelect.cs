using System;
using System.Collections.Generic;

namespace WebApplication.Data
{
    public delegate void LoopSelect();

    public interface ISelect
    {
        void AddParameter(string name, object value);
        void Execute();
        bool IsNull(string nameColumn);
        object Get(string nameColumn);
        string GetString(string nameColumn);
        string GetString(string nameColumn, string defaultValue);
        string GetStringOrNull(string nameColumn);
        byte GetByte(string nameColumn);
        byte GetByte(string nameColumn, byte defaultValue);
        byte? GetByteOrNull(string nameColumn);
        short GetShort(string nameColumn);
        short GetShort(string nameColumn, short defaultValue);
        short? GetShortOrNull(string nameColumn);
        int GetInt(string nameColumn);
        int GetInt(string nameColumn, int defaultValue);
        int? GetIntOrNull(string nameColumn);
        long GetLong(string nameColumn);
        long GetLong(string nameColumn, long defaultValue);
        long? GetLongOrNull(string nameColumn);
        float GetFloat(string nameColumn);
        float GetFloat(string nameColumn, float defaultValue);
        float? GetFloatOrNull(string nameColumn);
        double GetDouble(string nameColumn);
        double GetDouble(string nameColumn, double defaultValue);
        double? GetDoubleOrNull(string nameColumn);
        decimal GetDecimal(string nameColumn, byte decimals = 2);
        decimal GetDecimal(string nameColumn, decimal defaultValue, byte decimals = 2);
        decimal? GetDecimalOrNull(string nameColumn, byte decimals = 2);
        DateTime GetDateTime(string nameColumn);
        DateTime GetDateTime(string nameColumn, DateTime defaultValue);
        DateTime? GetDateTimeOrNull(string nameColumn);
        TimeSpan GetTimeSpan(string nameColumn);
        TimeSpan GetTimeSpan(string nameColumn, TimeSpan defaultValue);
        TimeSpan? GetTimeSpanOrNull(string nameColumn);
        char GetChar(string nameColumn);
        char GetChar(string nameColumn, char defaultValue);
        char? GetCharOrNull(string nameColumn);
        bool GetBoolean(string nameColumn);
        byte[] GetBytes(string nameColumn);
        List<Dictionary<string, object>> GetAll();
        void Loop(LoopSelect loopSelect);
        ISelectResult GetResult(Dictionary<string, object> rowData, string nameColumn);
        bool Any();
        int Count();
    }
}