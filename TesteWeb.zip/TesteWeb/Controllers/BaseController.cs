using Microsoft.AspNetCore.Mvc;

namespace WebApplication.Controllers
{
    public class BaseController : Controller
    {
        protected void AddValueInCache(string key, object value)
        {
            HttpContext.Session.SetObject(key, value);

            if (key.ToUpper().Contains("V_"))
            {
                ViewData[key] = value;
            }
        }

        protected T GetValueInCache<T>(string key)
        {
            var value = HttpContext.Session.GetObject<T>(key);
            
            if (key.ToUpper().Contains("V_"))
            {
                ViewData[key] = value;
            }
            
            return value;
        }
    }
}