using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApplication.Data;

namespace WebApplication.Controllers
{
    public class PaginaController : BaseController
    {
        public IActionResult Index()
        {
            PopulateMovieType();

            var lista = new List<PaginaModel>();
            lista.Add(new PaginaModel {Name = "Teste1", IsWorking = true});
            lista.Add(new PaginaModel {Name = "Teste2", IsWorking = false});

            AddValueInCache("V_Teste", lista);
            //return View("~/views/home/pagina.cshtml", lista);
            return View("~/views/home/pagina.cshtml");
        }

        private void PopulateMovieType()
        {
            var items = new List<SelectListItem>();
            items.Add(new SelectListItem { Text = "Selecione", Value = "-1", Selected = true });
            items.Add(new SelectListItem { Text = "MyId1", Value = "1" });
            items.Add(new SelectListItem { Text = "MyId2", Value = "2" });
            AddValueInCache("V_MovieType", items);
        }

        [HttpPost]
        public void OnSelect_MovieType(int value)
        {
            var values = GetValueInCache<List<SelectListItem>>("V_MovieType");
            var text = values.Where(a => a.Value == value.ToString()).FirstOrDefault();

            var dados = DataBaseProvider.NewSelect("select * from ArquivoTexto");
            dados.Execute();
            var data = dados.Any();
            var abc = dados.GetString("NOME");
        }
    }

    public class PaginaModel
    {
        public string Name {get; set;}
        public bool IsWorking {get; set;}
    }
}
