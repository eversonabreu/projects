using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace WebApplication
{
    public class Middleware
    {
        private readonly RequestDelegate next;
        private bool isStartSession;

        public Middleware(RequestDelegate next)
        {
            this.next = next;
            isStartSession = true;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            string path = httpContext.Request.Path.Value;

            if (isStartSession)
            {
                isStartSession = false;
                httpContext.Session.SetString("S_LOGGED", "LOGGED");
            }

            if (httpContext.Session.GetString("S_LOGGED") != null)
            {
                await next.Invoke(httpContext);
            }
            else
            {
                //redirecionar página por sessão expirada
            }
        }
    }
}